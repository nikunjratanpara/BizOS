-- Add New column in FormConfig for Fetch record from Database.
select * from GridConfiguration;
select * from GridColumnConfiguration;
select * from FormFieldConfiguration;

select dbo.GetObjectQuery('CatState');