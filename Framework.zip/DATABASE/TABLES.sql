DROP TABLE GridColumnConfiguration
DROP TABLE GridConfiguration
DROP TABLE FormFieldConfiguration
DROP TABLE FormConfiguration
DROP TABLE CatalogDictionary

CREATE TABLE CatalogDictionary
(
	CatalogId VARCHAR(20) CONSTRAINT PK_CatalogDictionary PRIMARY KEY,
	TableName VARCHAR(250),
	DisplayColumn VARCHAR(50),
	ValueColumn VARCHAR(50),
	Condition VARCHAR(1000),
	ObjectId RowVersion
)
CREATE TABLE FormConfiguration
(
	FormConfigId VARCHAR(20) NOT NULL CONSTRAINT PK_FormConfiguration PRIMARY KEY ,
	TableName VARCHAR(150) NOT NULL,
	GridConfigId VARCHAR(20),
	RowId UniqueIdentifier NOT NULL,
	ObjectId RowVersion
)
CREATE TABLE FormFieldConfiguration
(
	FormConfigId VARCHAR(20) NOT NULL,
	Name VARCHAR(50) NOT NULL,
	Label VARCHAR(50) NOT NULL,
	[Type] VARCHAR(50) NOT NULL,
	Placeholder varchar(50),
	CatId VARCHAR(20) Constraint FK_FormFieldConfiguration_CatalogDictionary_CatId References CatalogDictionary(CatalogId) ,
	MaxDate Datetime,
	MinDate Datetime,
	DisplayFormat Varchar(23),
	IsRequired BIT,
	MaxValue VARCHAR(50),
	MinValue VARCHAR(50),
	Pattern VARCHAR(250),
	SearchOperator Varchar(20),
	ObjectId RowVersion,
	CONSTRAINT PK_FormFieldConfiguration PRIMARY KEY (FormConfigId, Name),
	CONSTRAINT UK_FormFieldConfiguration_FieldName UNIQUE (FormConfigId,Label),
)
CREATE TABLE GridConfiguration
(
	GridConfigId varchar(20) CONSTRAINT PK_GridConfiguration PRIMARY KEY,
	PageSize int,
	SearchConfigId varchar(20)  Constraint FK_GridConfiguration_FormConfiguration_SearchConfigId References FormConfiguration(FormConfigId),
	Url varchar(250),
	Method varchar(10),
	Params varchar(max),
	TableName varchar(max),
	ColumnList varchar(max)
)
CREATE TABLE GridColumnConfiguration
(
	GridConfigId varchar(20) CONSTRAINT FK_GridColConfiguration_GridConfiguration_GridConfigId REFERENCES GridConfiguration(GridConfigId),
	DataField Varchar(20) NOT NULL,
    DataType varchar(20) NOT NULL,
	Header varchar(150),
	Formatter VARCHAR(100),
    ColSpan int,
    DefaultValue varchar(20),
    CssClass Varchar(50),
    Sortable bit,
    SortOrder varchar(4),
    Width int,
    Align varchar(10),
	CONSTRAINT PK_GridColumnConfiguration PRIMARY KEY (GridConfigId,DataField)
)

insert into FormConfiguration (FormConfigId, TableName, GridConfigId, RowId) Values 
('CatCountry', 'CatCountry', NULL, NewId()),
('CatState', 'CatState', 'GrdCatState', NEWID()),
('CatCity', 'CatCity', NULL ,NEWID()),
('CatStateSearch', 'CatState', NULL ,NEWID())

Insert into CatalogDictionary (CatalogId, TableName, DisplayColumn, ValueColumn) values
	('CatCountry', 'CatCountry', 'Name', 'Code'),
	('CatState', 'CatState', 'Name', 'Id'),
	('CatCity', 'CatCity', 'Name', 'Id')
Insert into FormFieldConfiguration (FormConfigId,Name,Label,[Type],CatId,IsRequired) 
	values ('CatCountry','name','Name','text',null,1),
	('CatCountry','code','Country Code','text',null,1),
	('CatCity','name','City Name','text',null,1),
	('CatCity','stateId','State','datacombo','CatState',1),
	('CatState','name','State Name','text',null,1),
	('CatState','country','Country','datacombo','CatCountry',1),
	('CatStateSearch','name','State Name','text',null,null),
	('CatStateSearch','country','Country','datacombo','CatCountry',null)
INSERT INTO GridConfiguration (GridConfigId, SearchConfigId, PageSize, Url, Method, Params,TableName, ColumnList) Values
	('GrdCatState','CatStateSearch',20,'/DynamicGrid/GrdCatState','post',null,'CatState','Name,Country' )
INSERT INTO GridColumnConfiguration(ColSpan,Width,Sortable,GridConfigId,DataField,Datatype,Header,DefaultValue,CssClass,SortOrder,Align) 
			VALUES (1,null,1,'GrdCatState','name','string','State Name','',null,'Asc','center'),
				   (1,null,1,'GrdCatState','country','string','Country','',null,'Asc','center')



CREATE TABLE CatCountry
(
	Name varchar(100) Not Null,
	Code varchar(10) Constraint PK_CatCountry Primary Key,
	ObjectId RowVersion
)

CREATE TABLE CatState
(
	Id int identity constraint PK_CatState Primary Key,
	Name varchar(100) Not Null,
	Country Varchar(10) Constraint FK_CatState_CatCountry_Country References CatCountry(Code),
	ObjectId RowVersion
)

CREATE TABLE CatCity
(
	Id int identity constraint PK_CatCity Primary Key,
	Name varchar(100) Not Null,
	StateId int Constraint FK_CatCity_CatState_StateId References CatState(Id),
	ObjectId RowVersion
)