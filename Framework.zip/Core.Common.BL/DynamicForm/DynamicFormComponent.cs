﻿using System.Collections.Generic;
using Core.Common.Contracts.DynamicForm;
using Core.Common.Contracts.DynamicForm.Models;
using Framework.Base.BL;
using Core.Common.Extensions;

namespace Core.Common.BL.DynamicForm
{
    internal class DynamicFormComponent : BusinessComponent, IDynamicFormComponent
    {
        private IDynamicFormRepository dynamicFormRepository;
        public IDynamicFormRepository DynamicFormRepository
        {
            get
            {
                return dynamicFormRepository = dynamicFormRepository ?? GetRepository<IDynamicFormRepository>();
            }
        }
        public FormConfiguration GetFormConfig(string FormName)
        {
            FormConfiguration formConfig = null;
            if (FormName.IsNotNullOrEmpty())
            {
                formConfig = DynamicFormRepository.GetFormConfig(FormName);
                formConfig.Controls = DynamicFormRepository.GetFormControls(FormName);
            }
            return formConfig;
        }

        public bool SaveForm(string FormName, dynamic formData)
        {
            return true;
        }
    }
}
