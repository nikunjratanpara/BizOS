﻿namespace Core.Common.Contracts.DynamicGrid.Models
{
    public class GridQuery
    {
        public string GridConfigId { get; set; }
        public string TableName { get; set; }
        public string columnList { get; set; }
    }
}
