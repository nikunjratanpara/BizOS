﻿using Core.Common.Contracts.DynamicForm.Models;
using System.Collections.Generic;

namespace Core.Common.Contracts.DynamicForm
{
    public interface IDynamicFormFacade
    {
        FormConfiguration GetFormConfig(string FormName);
        bool SaveForm(string FormName, dynamic formData);
    }
}
