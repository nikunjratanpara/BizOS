﻿namespace Core.Common.Contracts.DynamicForm.Models
{
    public enum ComboDisplayStyle
    {
        CodeDesciption = 0,
        Description = 1,
        Code = 2
    }
}
