﻿using Core.Common.Contracts.DynamicForm.Models;
using System.Collections.Generic;

namespace Core.Common.Contracts.DynamicForm
{
    public interface IDynamicFormRepository
    {
        FormConfiguration GetFormConfig(string CatalogId);
        List<FormFieldConfiguration> GetFormControls(string CatalogId);
    }
}
