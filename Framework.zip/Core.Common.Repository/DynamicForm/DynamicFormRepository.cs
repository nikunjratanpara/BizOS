﻿using Core.Common.Contracts.DynamicForm;
using Core.Common.Contracts.DynamicForm.Models;
using Framework.Base.BL.DataAccess;
using System.Collections.Generic;
using System;
using Dapper;
using System.Linq;

namespace Core.Common.Repository.DynamicForm
{
    internal class DynamicFormRepository : BaseRepository, IDynamicFormRepository
    {
        public List<FormFieldConfiguration> GetFormControls(string FormConfigId)
        {
            string sql = @"Select Name,Label,Type,Placeholder,SearchOperator,ObjectId,CatId,MaxDate,MinDate,DisplayFormat,IsRequired,MaxValue,MinValue,Pattern 
                    from FormFieldConfiguration 
                    where FormConfigId = @FormConfigId";
            return Connection.Query<FormFieldConfiguration, CatalogFieldConfig, DatetimeFieldConfig, Validations, FormFieldConfiguration>(
                sql ,
                (catalogFormConfiguration, catalogFieldConfig, datetimeFieldConfig, validations) => {
                    catalogFormConfiguration.CustomValidation = validations;
                    catalogFormConfiguration.TypeaheadOptions = catalogFieldConfig;
                    catalogFormConfiguration.DatetimePickerOptions = datetimeFieldConfig;
                    return catalogFormConfiguration;
                },
                new { FormConfigId = FormConfigId },
                splitOn : "CatId,MaxDate,IsRequired").AsList();
        }

        public FormConfiguration GetFormConfig(string FormConfigId)
        {
            string sql = @"Select * from FormConfiguration 
                    where FormConfigId = @FormConfigId";
            return Connection.Query<FormConfiguration>(sql, new { FormConfigId = FormConfigId }).FirstOrDefault();
        }

        public override object GetPocoObject<T>(T Model)
        {
            return Model;   
        }
    }
}
